﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace MathFigher.Math.Views
{
    public class MathVariableLetterView : MathVariableView
    {
        public MathVariableLetterView(MathVariableLetter variable, float h, float spacing, Font font)
        {
            _texture = DrawStringToTexture(variable.StringToken, h, font);
        }
    }
}
